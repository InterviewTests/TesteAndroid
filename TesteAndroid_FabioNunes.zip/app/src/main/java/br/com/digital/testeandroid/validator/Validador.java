package br.com.digital.testeandroid.validator;

public interface Validador {
    boolean estaValido();
}
