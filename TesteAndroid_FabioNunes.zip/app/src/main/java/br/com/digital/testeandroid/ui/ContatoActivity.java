package br.com.digital.testeandroid.ui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import br.com.digital.testeandroid.R;
import br.com.digital.testeandroid.validator.FormataTelefoneComDDD;
import br.com.digital.testeandroid.validator.ValidaEmail;
import br.com.digital.testeandroid.validator.ValidaTelefoneComDDD;
import br.com.digital.testeandroid.validator.ValidacaoPadrao;
import br.com.digital.testeandroid.validator.ValidacaoPadraoCheckbox;
import br.com.digital.testeandroid.validator.Validador;

public class ContatoActivity extends AppCompatActivity {
    private int botaoSelecionado = 0;
    private final static int ACTIVITY_CONTATO = 1;
    private final static int ACTIVITY_INVESTIMENTO = 2;
    private final static int ACTIVITY_CONTATO_SUCESSO = 3;
    private final List<Validador> validadores = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contato);

        String json = getIntent().getStringExtra("json");
        if (json == null) {
            Toast.makeText(this,"Sem comunicação com a Internet",Toast.LENGTH_LONG).show();
        }

        inicializarCampos();
    }

    private void inicializarCampos() {
        configuraCampoNomeCompleto();
        configuraCampoEmail();
        configuraCampoTelefone();
        configuraBotaoEnviar();
        configuraBotaoInvestimento();
        configuraBotaoContato();
    }

    private void configuraCampoNomeCompleto() {
        TextInputLayout textInputNomeCompleto = findViewById(R.id.contato_nome_completo);
        adicionaValidacaoPadrao(textInputNomeCompleto);
    }

    private void configuraCampoEmail() {
        TextInputLayout textInputEmail = findViewById(R.id.contato_email);
        EditText campoEmail = textInputEmail.getEditText();
        final ValidaEmail validador = new ValidaEmail(textInputEmail);
        validadores.add(validador);
        campoEmail.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(!hasFocus) {
                    validador.estaValido();
                }
            }
        });
    }


    private void configuraCampoTelefone() {
        TextInputLayout textInputTelefone = findViewById(R.id.contato_telefone);
        final EditText campoTelefoneComDDD = textInputTelefone.getEditText();
        final ValidaTelefoneComDDD validador = new ValidaTelefoneComDDD(textInputTelefone);
        final FormataTelefoneComDDD formatador = new FormataTelefoneComDDD();
        validadores.add(validador);
        campoTelefoneComDDD.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                String telefoneComDDD = campoTelefoneComDDD.getText().toString();
                if(hasFocus) {
                    String telefoneComDDDSemFormatacao = formatador.remove(telefoneComDDD);
                    campoTelefoneComDDD.setText(telefoneComDDDSemFormatacao);
                } else {
                    validador.estaValido();
                }
            }
        });
    }


    private void configuraBotaoEnviar() {
        Button botaoEnviar = findViewById(R.id.investimento_botao_enviar);
        botaoEnviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean formularioEstaValido = validaTodosCampos();
                if(formularioEstaValido) {
                    botaoSelecionado = ACTIVITY_CONTATO_SUCESSO;
                    sair();
                }
            }
        });
    }

    private void configuraBotaoContato() {
        Button botaoContato = findViewById(R.id.investimento_botao_contato);
        botaoContato.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                botaoSelecionado = ACTIVITY_CONTATO;
            }
        });
    }

    private void configuraBotaoInvestimento() {
        Button botaoInvestimento = findViewById(R.id.investimento_botao_investimento);
        botaoInvestimento.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                botaoSelecionado = ACTIVITY_INVESTIMENTO;
                sair();
            }
        });
    }

    private void adicionaValidacaoPadrao(final TextInputLayout textInputCampo) {
        final EditText campo = textInputCampo.getEditText();
        final ValidacaoPadrao validador = new ValidacaoPadrao(textInputCampo);
        validadores.add(validador);
        campo.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(!hasFocus) {  //não tem o foco
                    validador.estaValido();
                }
            }
        });
    }

    private boolean validaTodosCampos() {
        boolean formularioEstaValido = true;
        for (Validador validador : validadores) {
            if(!validador.estaValido()) {
                formularioEstaValido = false;
            };
        }
        return formularioEstaValido;
    }

    @Override
    public void onBackPressed() {
        botaoSelecionado = 0;
        sair();
    }

    public void sair() {
        Intent it = new Intent();
        it.putExtra("OK",botaoSelecionado);
        setResult(Activity.RESULT_OK,it);
        finish();
    }

}
