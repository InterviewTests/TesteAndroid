package br.com.digital.testeandroid.validator;

import android.support.annotation.NonNull;

public class FormataTelefoneComDDD {

    @NonNull
    public String formata(String telefoneComDDD) {
        return telefoneComDDD.replaceAll("([0-9]{2})([0-9]{4,5})([0-9]{4})","($1) $2-$3");
    }

    @NonNull
    public String remove(String telefoneComDDD) {
        return telefoneComDDD
                .replace("(", "")
                .replace(")", "")
                .replace(" ","")
                .replace("-", "");
    }

}
