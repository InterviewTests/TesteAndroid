package br.com.digital.testeandroid.task;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import br.com.digital.testeandroid.support.WebClient;
import br.com.digital.testeandroid.ui.MainActivity;

public class CelulaTask extends AsyncTask<Void, Void, String> {

    private ProgressDialog dialog;
    private MainActivity context;

    public CelulaTask(MainActivity context) {
        this.context = context;
    }

    @Override
    protected void onPreExecute() {
        //super.onPreExecute();
        dialog = ProgressDialog.show(context, "Aguarde", "Buscando células...", true, true);
    }

    @Override
    protected String doInBackground(Void... params) {
        WebClient client = new WebClient("https://floating-mountain-50292.herokuapp.com/cells.json");
        String resposta = client.getJSON(15000);
        return resposta; //envia para a thread principal
    }

    @Override
    protected void onPostExecute(String resposta) {
//        super.onPostExecute(o);
        dialog.dismiss();
        context.recebeJsonContato(resposta);

    }

}
