package br.com.digital.testeandroid.validator;
import android.support.design.widget.TextInputLayout;
import android.widget.EditText;

public class ValidaTelefoneComDDD implements Validador {

    private static final CharSequence DEVE_TER_DEZ_OU_ONZE_DIGITOS = "Telefone dever ter entre 10 a 11 dígitos";
    private final TextInputLayout textInputTelefoneComDDD;
    private final EditText campoTelefoneComDDD;
    private final ValidacaoPadrao validacaoPadrao;
    private final FormataTelefoneComDDD formatador = new FormataTelefoneComDDD();

    public ValidaTelefoneComDDD(TextInputLayout textInputTelefoneComDDD) {
        this.textInputTelefoneComDDD = textInputTelefoneComDDD;
        this.validacaoPadrao = new ValidacaoPadrao(textInputTelefoneComDDD);
        this.campoTelefoneComDDD = this.textInputTelefoneComDDD.getEditText();
    }

    private boolean validaEntreDezOuOnzeDigitos(String telefoneComDDD) {
        int digitos = telefoneComDDD.length();
        if(digitos < 10 || digitos > 11) {
            textInputTelefoneComDDD.setError(DEVE_TER_DEZ_OU_ONZE_DIGITOS);
            return false;
        }
        return true;
    }

    @Override
    public boolean estaValido() {
        if(!validacaoPadrao.estaValido()) return false;
        String telefoneComDDD = campoTelefoneComDDD.getText().toString();
        String telefoneComDDDSemFormatacao = formatador.remove(telefoneComDDD);
        if(!validaEntreDezOuOnzeDigitos(telefoneComDDDSemFormatacao)) return false;
        adicionaFormatacao(telefoneComDDDSemFormatacao);
        return true;
    }

    private void adicionaFormatacao(String telefoneComDDD) {
        String telefoneComDDDFormatado = formatador.formata(telefoneComDDD);
        campoTelefoneComDDD.setText(telefoneComDDDFormatado);
    }
}
