package br.com.digital.testeandroid.adapter;

import android.content.Context;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

import br.com.digital.testeandroid.R;
import br.com.digital.testeandroid.model.Fundo;

public class FundosAdapter extends BaseAdapter {
    private final List<Fundo> fundos;
    private final Context context;

    public FundosAdapter(List<Fundo> fundos, Context context) {
        this.fundos = fundos;
        this.context = context;
    }

    @Override
    public int getCount() {
        return fundos.size();
    }

    @Override
    public Object getItem(int position) {
        return fundos.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Fundo fundo = fundos.get(position);
        LayoutInflater inflater = LayoutInflater.from(context);

        View view =convertView;
        TextView coluna1=null;
        TextView coluna2=null;
        TextView coluna3=null;
        View linha=null;

        //Criar linha traço
        if(fundo.getNivel().equals("linha")) {
            view = inflater.inflate(R.layout.list_item_linha, parent, false);
            return view;
        }

        //criar linha em branco
        if(fundo.getNivel().equals("espaco")) {
            view = inflater.inflate(R.layout.list_item_espaco, parent, false);
            return view;
        }

        //Criar gráfico do risco
        if(fundo.getNivel().equals("risk")) {
            view = inflater.inflate(R.layout.list_item_grau_risco, parent, false);
            int grau = Integer.parseInt(fundo.getColuna1());
            TextView sinal=null;
            View viewGrafico=null;
            switch (grau) {
                case 1: sinal = view.findViewById(R.id.list_grau_text_1);
                    viewGrafico = view.findViewById(R.id.list_grau_1);
                    break;
                case 2: sinal = view.findViewById(R.id.list_grau_text_2);
                    viewGrafico = view.findViewById(R.id.list_grau_2);
                    break;
                case 3: sinal = view.findViewById(R.id.list_grau_text_3);
                    viewGrafico = view.findViewById(R.id.list_grau_3);
                    break;
                case 4: sinal = view.findViewById(R.id.list_grau_text_4);
                    viewGrafico = view.findViewById(R.id.list_grau_4);
                    break;
                case 5: sinal = view.findViewById(R.id.list_grau_text_5);
                    viewGrafico = view.findViewById(R.id.list_grau_5);
                    break;
            }
            sinal.setVisibility(View.VISIBLE);
            viewGrafico.getLayoutParams().height = 50;
            return view;
        }


        //Crar layout de acordo com a quantidade de colunas
        if (fundo.getQtd() == 1) {
            view = inflater.inflate(R.layout.list_item1, parent, false);
            coluna1 = view.findViewById(R.id.item_coluna1);
        } else if (fundo.getQtd() == 2){
            if (fundo.getNivel().equals("downInfo")) {
                view = inflater.inflate(R.layout.list_tem2img, parent, false);
            } else {
                view = inflater.inflate(R.layout.list_item2, parent, false);
            }
            coluna1 = view.findViewById(R.id.item_coluna1);
            coluna2 = view.findViewById(R.id.item_coluna2);
        } else {
            view = inflater.inflate(R.layout.list_item3, parent, false);
            coluna1 = view.findViewById(R.id.item_coluna1);
            coluna2 = view.findViewById(R.id.item_coluna2);
            coluna3 = view.findViewById(R.id.item_coluna3);
        }

        configuraFundName(fundo, coluna1);
        configuraNegrito(fundo, coluna1);
        configuraFundoCDI(fundo, coluna2, coluna3);
        coluna1.setText(fundo.getColuna1());
        configuraDuasColunas(fundo, coluna2);
        configuraTresColunas(fundo, coluna2, coluna3);

        if(fundo.getNivel().equals("title")
                || fundo.getNivel().equals("whatIs")
                || fundo.getNivel().equals("riskTitle")
                || fundo.getNivel().equals("infoTitle") ) {
            coluna1.setTextColor(context.getResources().getColor(R.color.colorCinzaEscuro));
        }


        return view;
    }

    private void configuraTresColunas(Fundo fundo, TextView coluna2, TextView coluna3) {
        if (fundo.getQtd() == 3) {
            coluna2.setText(fundo.getColuna2());
            coluna3.setText(fundo.getColuna3());
            if(!fundo.getNivel().equals("cabecalhomesano")) {
                coluna2.setTextColor(context.getResources().getColor(R.color.colorCinzaEscuro2));
                coluna3.setTextColor(context.getResources().getColor(R.color.colorCinzaEscuro2));
            }
        }
    }

    private void configuraDuasColunas(Fundo fundo, TextView coluna2) {
        if (fundo.getQtd() == 2) {
            if (!fundo.getNivel().equals("downInfo")) {
                coluna2.setText(fundo.getColuna2());
                coluna2.setTextColor(context.getResources().getColor(R.color.colorCinzaEscuro2));
            }
        }
    }

    private void configuraNegrito(Fundo fundo, TextView coluna1) {
        if(fundo.getNivel().equals("whatIs")
                || fundo.getNivel().equals("riskTitle")
                || fundo.getNivel().equals("title")
                || fundo.getNivel().equals("infoTitle")) {
            coluna1.setTypeface(null, Typeface.BOLD);
        }
    }

    private void configuraFundoCDI(Fundo fundo, TextView coluna2, TextView coluna3) {
        if(fundo.getNivel().equals("cabecalhomesano")) {
            coluna2.setTextColor(context.getResources().getColor(R.color.colorCinza));
            coluna3.setTextColor(context.getResources().getColor(R.color.colorCinza));
        }
    }

    private void configuraFundName(Fundo fundo, TextView coluna1) {
        coluna1.setTextColor(context.getResources().getColor(R.color.colorCinza));
        if(fundo.getNivel().equals("fundName")) {
            coluna1.setTextSize(20);
            coluna1.setTypeface(null, Typeface.BOLD);
            coluna1.setTextColor(context.getResources().getColor(android.R.color.black));
        }
    }
}
