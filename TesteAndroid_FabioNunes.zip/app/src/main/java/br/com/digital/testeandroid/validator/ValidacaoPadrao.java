package br.com.digital.testeandroid.validator;

import android.support.design.widget.TextInputLayout;
import android.widget.CheckBox;
import android.widget.EditText;

public class ValidacaoPadrao implements Validador {
    private static final CharSequence CAMPO_OBRIGATORIO = "Campo obrigatório";
    private final TextInputLayout textInputCampo;
    private final EditText campo;

    public ValidacaoPadrao(TextInputLayout textInputCampo) {
        this.textInputCampo = textInputCampo;
        this.campo = this.textInputCampo.getEditText();
    }

    private boolean validaCampoObrigatorio() {
        String texto = campo.getText().toString();
        if(texto.isEmpty()) {
            textInputCampo.setError(CAMPO_OBRIGATORIO);
            return false;
        }
        return true;
    }

    private boolean validaCampoObrigatorioCheck(CheckBox campo) {
        boolean check = campo.isChecked();
        if(!check) {
            textInputCampo.setError(CAMPO_OBRIGATORIO);
            return false;
        }
        return true;
    }

    private void removeErro() {
        textInputCampo.setError(null);
        textInputCampo.setErrorEnabled(false);
    }

    @Override
    public boolean estaValido() {
        if(!validaCampoObrigatorio()) return false;
        removeErro();
        return true;
    }

}
