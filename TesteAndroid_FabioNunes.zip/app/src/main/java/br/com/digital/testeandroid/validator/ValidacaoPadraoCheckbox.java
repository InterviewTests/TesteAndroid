package br.com.digital.testeandroid.validator;

import android.support.design.widget.TextInputLayout;
import android.widget.CheckBox;
import android.widget.EditText;

public class ValidacaoPadraoCheckbox implements Validador {
    private static final CharSequence CAMPO_OBRIGATORIO = "Campo obrigatório";
    private final CheckBox check;

    public ValidacaoPadraoCheckbox(CheckBox check) {
        this.check = check;
    }

    private boolean validaCampoObrigatorio() {
        boolean campo = check.isChecked();
        if(!campo) {
    //        textInputCampo.setError(CAMPO_OBRIGATORIO);
            return false;
        }
        return true;
    }

    private void removeErro() {
    }

    @Override
    public boolean estaValido() {
        if(!validaCampoObrigatorio()) return false;
        removeErro();
        return true;
    }

}
