package br.com.digital.testeandroid.ui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.List;

import br.com.digital.testeandroid.R;
import br.com.digital.testeandroid.adapter.FundosAdapter;
import br.com.digital.testeandroid.model.Fundo;
import br.com.digital.testeandroid.support.Converter;

public class InvestimentoActivity extends AppCompatActivity {
    private int botaoSelecionado = 0;
    private final static int ACTIVITY_CONTATO = 1;
    private final static int ACTIVITY_INVESTIMENTO = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_investimento);

        String json = getIntent().getStringExtra("json");
        if (json == null) {
            Toast.makeText(this,"Sem comunicação com a Internet",Toast.LENGTH_LONG).show();
            configuraBotaoContato();
            return;
        }

        Converter converter = new Converter();
        List<Fundo> fundos = converter.parseJSONFundos(json);

        configuraLista(fundos);
        configuraBotaoInvestir();
        configuraBotaoInvestimento();
        configuraBotaoContato();
    }

    private void configuraLista(List<Fundo> fundos) {
        ListView lista = findViewById(R.id.investimento_lista);
        FundosAdapter adapter = new FundosAdapter(fundos, InvestimentoActivity.this);
        lista.setAdapter(adapter);
    }

    private void configuraBotaoContato() {
        Button botaoContato = findViewById(R.id.investimento_botao_contato);
        botaoContato.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                botaoSelecionado = ACTIVITY_CONTATO;
                sair();
            }
        });
    }

    private void configuraBotaoInvestimento() {
        Button botaoInvestimento = findViewById(R.id.investimento_botao_investimento);
        botaoInvestimento.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                botaoSelecionado = ACTIVITY_INVESTIMENTO;
            }
        });
    }

    private void configuraBotaoInvestir() {
        Button botaoInvestir = findViewById(R.id.investimento_botao_enviar);
        botaoInvestir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(InvestimentoActivity.this,"Investir", Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override
    public void onBackPressed() {
        botaoSelecionado = 0;
        sair();
    }

    public void sair() {
        Intent it = new Intent();
        it.putExtra("OK",botaoSelecionado);
        setResult(Activity.RESULT_OK,it);
        finish();
    }


}
