package br.com.digital.testeandroid.ui;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import br.com.digital.testeandroid.R;
import br.com.digital.testeandroid.task.CelulaTask;
import br.com.digital.testeandroid.task.FundosTask;

public class MainActivity extends AppCompatActivity {
    private final static int ACTIVITY_CONTATO = 1;
    private final static int ACTIVITY_INVESTIMENTO = 2;
    private final static int ACTIVITY_CONTATO_SUCESSO = 3;
    private int activitySelecionada;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        carregaContato();
    }

    public void recebeJsonContato(String json) {
        activitySelecionada = ACTIVITY_CONTATO;
        Intent intent = new Intent(MainActivity.this,ContatoActivity.class);
        intent.putExtra("json",json);
        startActivityForResult(intent,ACTIVITY_CONTATO);
    }

    public void recebeJsonFundos(String json) {
        activitySelecionada = ACTIVITY_INVESTIMENTO;
        Intent intent = new Intent(MainActivity.this,InvestimentoActivity.class);
        intent.putExtra("json",json);
        startActivityForResult(intent,ACTIVITY_INVESTIMENTO);
    }

    public void carregaContato() {
        new CelulaTask(MainActivity.this).execute();
    }

    public void carregaInvestimento() {
        new FundosTask(MainActivity.this).execute();
    }

    public void carregaContatoSucesso() {
        activitySelecionada = ACTIVITY_CONTATO_SUCESSO;
        Intent intent = new Intent(MainActivity.this,ContatoSucessoActivity.class);
        startActivityForResult(intent,ACTIVITY_CONTATO_SUCESSO);
    }

    @Override
    protected void onActivityResult(int codigo, int resultado,Intent it) {
        if(resultado == RESULT_OK) {
            Bundle params = it != null ? it.getExtras() : null;
            if (params != null) {
                int retorno = params.getInt("OK");
                if (retorno == ACTIVITY_CONTATO) {
                    carregaContato();
                } else if(retorno == ACTIVITY_CONTATO_SUCESSO) {
                    carregaContatoSucesso();
                } else if(retorno == ACTIVITY_INVESTIMENTO) {
                    carregaInvestimento();
                } else {
                    finish();
                }
            } else {
                finish();
            }
        }
    }

    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        savedInstanceState.putInt("activity_selecionada", activitySelecionada);
        super.onSaveInstanceState(savedInstanceState);
    }

    @Override
    public void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        activitySelecionada = savedInstanceState.getInt("activity_selecionada");
    }
}
