package br.com.digital.testeandroid.ui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import br.com.digital.testeandroid.R;

public class ContatoSucessoActivity extends AppCompatActivity {
    private int botaoSelecionado = 0;
    private final static int ACTIVITY_CONTATO = 1;
    private final static int ACTIVITY_INVESTIMENTO = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contato_sucesso);

        configuraBotaoInvestimento();
        configuraBotaoContato();
    }

    private void configuraBotaoContato() {
        Button botaoContato = findViewById(R.id.investimento_botao_contato);
        botaoContato.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                botaoSelecionado = ACTIVITY_CONTATO;
                sair();
            }
        });
    }

    private void configuraBotaoInvestimento() {
        Button botaoInvestimento = findViewById(R.id.investimento_botao_investimento);
        botaoInvestimento.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                botaoSelecionado = ACTIVITY_INVESTIMENTO;
                sair();
            }
        });
    }

    @Override
    public void onBackPressed() {
        botaoSelecionado = 1;
        sair();
    }

    public void sair() {
        Intent it = new Intent();
        it.putExtra("OK",botaoSelecionado);
        setResult(Activity.RESULT_OK,it);
        finish();
    }




}
