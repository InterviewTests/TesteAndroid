package br.com.digital.testeandroid.support;

import android.support.annotation.NonNull;
import android.util.Log;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import br.com.digital.testeandroid.model.Celula;
import br.com.digital.testeandroid.model.Fundo;

public class Converter {
    private List<Fundo> fundos = new ArrayList<Fundo>();

    public List<Celula> parseJSON(String json) {
        if (json != null) {
            try {
                List<Celula> celulas = new ArrayList<Celula>();
                JSONObject jsonObj = new JSONObject(json);

                JSONArray jarray = jsonObj.getJSONArray("cells");

                for (int i = 0; i < jarray.length(); i++) {
                    JSONObject c = jarray.getJSONObject(i);

                    Celula celula = new Celula();

                    celula.setId(c.getLong("id"));
                    celula.setType(c.getInt("type"));
                    celula.setMessage(c.getString("message"));
                    celula.setTypeField(c.getString("typefield"));
                    celula.setHidden(c.getBoolean("hidden"));
                    celula.setTopSpacing(c.getDouble("topSpacing"));
                    celula.setTypeField(c.getString("show"));
                    celula.setRequired(c.getBoolean("required"));

                    celulas.add(celula);
                }
                return celulas;
            } catch (JSONException e) {
                e.printStackTrace();
                return null;
            }
        } else {
            return null;
        }
    }

    public List<Fundo> parseJSONFundos(String json) {
        if (json != null) {
            try {
                JSONObject jsonObj = new JSONObject(json);
                JSONObject jsonScreen = extrairScreen(jsonObj);
                adicionaNaLista("title",jsonScreen.getString("title"));
                adicionaEspacoNaLista();
                adicionaNaLista("fundName",jsonScreen.getString("fundName"));
                adicionaLinhaTracejadaNaLista();
                adicionaEspacoNaLista();
                adicionaNaLista("whatIs",jsonScreen.getString("whatIs"));
                adicionaNaLista("screen",jsonScreen.getString("definition"));
                adicionaEspacoNaLista();
                adicionaEspacoNaLista();
                adicionaEspacoNaLista();
                adicionaEspacoNaLista();
                adicionaNaLista("riskTitle",jsonScreen.getString("riskTitle"));
                adicionaEspacoNaLista();
                adicionaEspacoNaLista();
                adicionaNaLista("risk",jsonScreen.getString("risk"));
                adicionaEspacoNaLista();
                adicionaEspacoNaLista();
                adicionaEspacoNaLista();
                adicionaEspacoNaLista();
                adicionaEspacoNaLista();
                adicionaNaLista("infoTitle",jsonScreen.getString("infoTitle"));

                JSONObject jsonMoreInfo = extrairMoreInfo(jsonScreen);
                adicionaCabecalhoFundoCDI();
                adicionaMes(jsonMoreInfo);
                adcionaAno(jsonMoreInfo);
                adiciona12Meses(jsonMoreInfo);
                adicionaLinhaTracejadaNaLista();

                adicionaInfo(jsonScreen);
                adicionaDowninfo(jsonScreen);

                return fundos;
            } catch (JSONException e) {
                e.printStackTrace();
                return null;
            }
        } else {
            return null;
        }
    }

    private void adicionaDowninfo(JSONObject jsonScreen) throws JSONException {
        JSONArray jarrayDownInfo = jsonScreen.getJSONArray("downInfo");
        for (int i = 0; i < jarrayDownInfo.length(); i++) {
            JSONObject jsonDownInfo = jarrayDownInfo.getJSONObject(i);
            adicionaNaLista("downInfo",jsonDownInfo.getString("name"),"" );
        }
    }

    private void adicionaInfo(JSONObject jsonScreen) throws JSONException {
        JSONArray jarrayInfo = jsonScreen.getJSONArray("info");
        for (int i = 0; i < jarrayInfo.length(); i++) {
            JSONObject jsonInfo = jarrayInfo.getJSONObject(i);
            adicionaNaLista("info",jsonInfo.getString("name"),jsonInfo.getString("data") );
        }
    }

    private void adiciona12Meses(JSONObject jsonMoreInfo) throws JSONException {
        String months12 = jsonMoreInfo.getString("12months");
        JSONObject json12Months = new JSONObject(months12);
        adicionaNaLista("mesano","12 meses",json12Months.getString("fund")+"%",json12Months.getString("CDI")+"%" );
    }

    private void adcionaAno(JSONObject jsonMoreInfo) throws JSONException {
        String year = jsonMoreInfo.getString("year");
        JSONObject jsonYear = new JSONObject(year);
        adicionaNaLista("mesano","No ano",jsonYear.getString("fund")+"%",jsonYear.getString("CDI")+"%" );
    }

    private void adicionaMes(JSONObject jsonMoreInfo) throws JSONException {
        String month = jsonMoreInfo.getString("month");
        JSONObject jsonMonth = new JSONObject(month);
        adicionaNaLista("mesano","No mês", jsonMonth.getString("fund")+"%",jsonMonth.getString("CDI")+"%" );
    }

    private void adicionaCabecalhoFundoCDI() {
        adicionaNaLista("cabecalhomesano","", "Fundo","CDI" );
    }

    @NonNull
    private JSONObject extrairMoreInfo(JSONObject jsonScreen) throws JSONException {
        String moreInfo = jsonScreen.getString("moreInfo");
        return new JSONObject(moreInfo);
    }

    @NonNull
    private JSONObject extrairScreen(JSONObject jsonObj) throws JSONException {
        String screen = jsonObj.getString("screen");
        return new JSONObject(screen);
    }

    private void adicionaLinhaTracejadaNaLista() {
        adicionaNaLista("linha","linha");
    }

    private void adicionaEspacoNaLista() {
        adicionaNaLista("espaco","espaco");
    }

    private void adicionaNaLista(String nivel, String coluna1) {
        Fundo fundo = new Fundo();
        fundo.setNivel(nivel);
        fundo.setColuna1(coluna1);
        fundo.setQtd(1);
        fundos.add(fundo);
    }

    private void adicionaNaLista(String nivel, String coluna1, String coluna2) {
        Fundo fundo = new Fundo();
        fundo.setNivel(nivel);
        fundo.setColuna1(coluna1);
        fundo.setColuna2(coluna2);
        fundo.setQtd(2);
        fundos.add(fundo);
    }

    private void adicionaNaLista(String nivel, String coluna1, String coluna2, String coluna3) {
        Fundo fundo = new Fundo();
        fundo.setNivel(nivel);
        fundo.setColuna1(coluna1);
        fundo.setColuna2(coluna2);
        fundo.setColuna3(coluna3);
        fundo.setQtd(3);
        fundos.add(fundo);
    }


}
