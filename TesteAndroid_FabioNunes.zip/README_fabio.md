# Show me the code

### # DESAFIO:

Instlar apk ..\TesteAndroid\app\release\app-release.apk